package com.payment.basicPaymentProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicPaymentProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicPaymentProjectApplication.class, args);
	}

}
